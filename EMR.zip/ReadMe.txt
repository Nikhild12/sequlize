package.json

  "scripts": {
    "start": "nodemon index.js",
    "eslint": "gulp eslint",
    "prod.build": "gulp prodbuild",
    "test": "jest"
  },